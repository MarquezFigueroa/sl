# American Sign Language Converter: (Words to ASL Spelling)

A Pen created on CodePen.io. Original URL: [https://codepen.io/leimapapa/pen/XygpgR](https://codepen.io/leimapapa/pen/XygpgR).

Took all of the American Sign Language letters from Wikipedia and added 'em as background images of CSS classes. Plugged that into my class array cycling code.